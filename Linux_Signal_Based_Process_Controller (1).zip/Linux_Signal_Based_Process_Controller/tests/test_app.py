import os
import time
import unittest
import app as controller


class ControllerApiTests(unittest.TestCase):
    def setUp(self):
        self.client = controller.app.test_client()
        controller.cleanup()
        controller._events.clear()

    def tearDown(self):
        controller.cleanup()

    def test_dashboard(self):
        response = self.client.get("/")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Signal Process Controller", response.data)
        self.assertIn(b"instructionInput", response.data)
        self.assertIn(b"workerRows", response.data)

    def test_health_and_process_listing(self):
        health = self.client.get("/api/health")
        self.assertEqual(health.status_code, 200)
        self.assertTrue(health.json["ok"])
        listing = self.client.get("/api/processes")
        self.assertEqual(listing.status_code, 200)
        self.assertGreaterEqual(listing.json["count"], 1)
        self.assertTrue(any(p["pid"] == os.getpid() for p in listing.json["processes"]))

    def test_invalid_signal_rejected(self):
        response = self.client.post("/api/demo/signal", json={"signal": "SIGKILL"})
        self.assertEqual(response.status_code, 400)
        self.assertIn("SIGSTOP", response.json["error"])

    def test_signal_without_child_rejected(self):
        response = self.client.post("/api/demo/signal", json={"signal": "SIGSTOP"})
        self.assertEqual(response.status_code, 409)

    def test_real_signal_lifecycle(self):
        started = self.client.post("/api/demo/start", json={})
        self.assertEqual(started.status_code, 201)
        pid = started.json["managed"]["pid"]
        duplicate = self.client.post("/api/demo/start", json={})
        self.assertEqual(duplicate.status_code, 409)

        paused = self.client.post("/api/demo/signal", json={"signal": "SIGSTOP"})
        self.assertEqual(paused.status_code, 200)
        self.assertEqual(paused.json["pid"], pid)
        self.assertEqual(paused.json["state"], "Stopped")

        resumed = self.client.post("/api/demo/signal", json={"signal": "SIGCONT"})
        self.assertEqual(resumed.status_code, 200)
        self.assertNotEqual(resumed.json["state"], "Stopped")

        interrupted = self.client.post("/api/demo/signal", json={"signal": "SIGINT"})
        self.assertEqual(interrupted.status_code, 200)
        self.assertEqual(interrupted.json["state"], "Exited")

        started2 = self.client.post("/api/demo/start", json={})
        self.assertEqual(started2.status_code, 201)
        terminated = self.client.post("/api/demo/signal", json={"signal": "SIGTERM"})
        self.assertEqual(terminated.status_code, 200)
        self.assertEqual(terminated.json["state"], "Exited")

        events = self.client.get("/api/events").json["events"]
        signals = [event["signal"] for event in events]
        self.assertIn("SIGSTOP", signals)
        self.assertIn("SIGCONT", signals)
        self.assertIn("SIGINT", signals)
        self.assertIn("SIGTERM", signals)

    def test_create_multiple_workers_from_ui_api(self):
        response = self.client.post("/api/demo/workers", json={"count": 5, "kind": "sleeper"})
        self.assertEqual(response.status_code, 201)
        pids = response.json["pids"]
        self.assertEqual(len(pids), 5)
        self.assertEqual(len(set(pids)), 5)
        workers = self.client.get("/api/demo/workers").json["workers"]
        self.assertEqual({w["pid"] for w in workers}, set(pids))
        self.assertTrue(all(w["state"] in {"R", "S", "D", "T", "I", "?"} for w in workers))

    def test_worker_signals_only_apply_to_managed_workers(self):
        created = self.client.post("/api/demo/workers", json={"count": 1, "kind": "sleeper"})
        self.assertEqual(created.status_code, 201)
        pid = created.json["pids"][0]
        paused = self.client.post(f"/api/demo/workers/{pid}/signal", json={"signal": "SIGSTOP"})
        self.assertEqual(paused.status_code, 200)
        self.assertEqual(paused.json["state"], "Stopped")
        resumed = self.client.post(f"/api/demo/workers/{pid}/signal", json={"signal": "SIGCONT"})
        self.assertEqual(resumed.status_code, 200)
        stopped = self.client.post(f"/api/demo/workers/{pid}/signal", json={"signal": "SIGTERM"})
        self.assertEqual(stopped.status_code, 200)
        self.assertEqual(stopped.json["state"], "Exited")
        foreign = self.client.post(f"/api/demo/workers/{os.getpid()}/signal", json={"signal": "SIGTERM"})
        self.assertEqual(foreign.status_code, 404)

    def test_instruction_creates_workers_and_rejects_arbitrary_input(self):
        response = self.client.post("/api/instructions", json={"instruction": "create 3 sleepers"})
        self.assertEqual(response.status_code, 200)
        self.assertEqual(len(response.json["pids"]), 3)
        bad = self.client.post("/api/instructions", json={"instruction": "run rm -rf /"})
        self.assertEqual(bad.status_code, 400)

    def test_worker_batch_limits_and_kind_validation(self):
        too_many = self.client.post("/api/demo/workers", json={"count": 31, "kind": "sleeper"})
        self.assertEqual(too_many.status_code, 400)
        bad_kind = self.client.post("/api/demo/workers", json={"count": 1, "kind": "arbitrary"})
        self.assertEqual(bad_kind.status_code, 400)


if __name__ == "__main__":
    unittest.main()
