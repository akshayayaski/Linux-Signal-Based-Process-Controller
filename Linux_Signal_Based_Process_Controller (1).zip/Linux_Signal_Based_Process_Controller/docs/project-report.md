# Project Report: Linux Signal-Based Process Controller

## Abstract
The Linux Signal-Based Process Controller is a local web dashboard that demonstrates operating-system process inspection and POSIX signal handling. A Flask backend reads live process metadata from `/proc`, starts a dedicated child process, and sends selected POSIX signals only to that child. A responsive HTML/CSS/JavaScript interface communicates with the backend through a REST API and displays process states, memory usage, operation results, and a timestamped event log.

## Problem statement
Learning process scheduling and signal handling can be abstract when students rely only on terminal commands or diagrams. Students need a controlled, visible environment in which they can observe actual process states and signal effects without risking unrelated system processes or requiring root access.

## Objectives
- Display real Linux processes and key metadata.
- Demonstrate `SIGSTOP`, `SIGCONT`, `SIGINT`, and `SIGTERM`.
- Restrict signal delivery to an application-managed test process.
- Provide a browser-based dashboard and REST endpoints.
- Let users create multiple real demo processes using UI controls or a constrained instruction field.
- Show worker PIDs, states, RSS, and per-worker controls while keeping signals restricted to dashboard-created processes.
- Log operations and return useful validation/error messages.
- Keep setup small enough for a college hackathon.

## System overview
The browser polls the Flask API every two seconds. Flask reads `/proc` for process data and maintains a `subprocess.Popen` reference to the demo child. Signal actions are validated against an allowlist and delivered using `os.kill()` to the PID belonging to that reference. Event records are held in a bounded in-memory list.

## Implementation details
- **Process discovery:** iterate numeric entries under `/proc`; read `/proc/PID/status` for process name, state, and `VmRSS`.
- **Managed process:** launch a small Python loop using `subprocess.Popen`, with stdin/stdout/stderr detached from the terminal and a new session.
- **Signal control:** use a strict signal allowlist and the stored `Popen.pid`; the browser cannot supply a PID.
- **State observation:** reread `/proc/PID/status` after pause/resume operations. Linux state `T` represents stopped.
- **Logging:** timestamp, operation/signal, target PID, result, status, and detail.
- **User-directed demo workers:** users select batch size and type (sleeper, memory demo, or low-CPU worker), or enter a supported instruction such as `create 10 sleepers`. Batches are capped at 30, total extra workers at 50, and memory allocation at 32 MB per worker.
- **Worker safety:** pause/resume/terminate endpoints accept only PIDs present in the dashboard-owned process registry. Arbitrary PIDs from user text are never signaled.
- **Frontend:** semantic HTML, responsive CSS, `fetch()` REST calls, two-second refresh loop, status indicators, and error display.

## Technologies
Python 3, Flask, HTML5, CSS3, JavaScript Fetch API, Linux `/proc`, `subprocess`, `os.kill`, and POSIX signals.

## Testing and results
The automated suite checks the dashboard route, health response, live `/proc` listing, managed process start, invalid signal rejection, signal lifecycle behavior, and bounded worker creation/instruction handling. On a Linux host, the expected demonstration is: start creates a child; SIGSTOP produces `T`/Stopped; SIGCONT resumes it; SIGINT and SIGTERM each terminate a child and are recorded. Exact process counts and RSS values vary by machine and user permissions.

## Limitations
- Designed for local educational use only.
- The Flask development server is not production-hardened.
- Event history is in memory and disappears when the server stops.
- Process visibility depends on Linux permissions and procfs settings.
- State transitions are asynchronous; UI polling can introduce a short delay.
- User instructions are intentionally limited to documented patterns; this is not an unrestricted natural-language agent.
- Worker registry and event history are in memory and reset when the server restarts.
- A SIGINT handler is installed in the child for deterministic demonstration; it is not a literal terminal keyboard interrupt.

## Future enhancements
- Persistent SQLite event history and export.
- Authentication and CSRF protection if multi-user access is needed.
- Charts for process state distribution and memory usage.
- Optional configurable refresh interval and pagination.
- Packaging as a systemd service with hardened permissions.

## Team of 3–4: suggested responsibilities
1. **Backend/Linux integration:** `/proc` parsing, managed subprocess lifecycle, signal delivery.
2. **Frontend/UI:** responsive dashboard, polling, status/error handling.
3. **Testing and QA:** API tests, signal state verification, WSL/Ubuntu setup validation.
4. **Documentation/presentation (optional fourth):** report, architecture diagram, demo script, screenshots, viva preparation.
