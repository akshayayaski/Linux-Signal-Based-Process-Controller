# Architecture

## Component diagram

```text
+------------------------------+
| Browser dashboard            |
| HTML / CSS / JavaScript      |
| polls every 2 seconds        |
+---------------+--------------+
                | HTTP / JSON (localhost)
                v
+------------------------------+
| Flask REST API               |
| /api/health                  |
| /api/processes               |
| /api/demo/start              |
| /api/demo/signal             |
| /api/demo/workers             |
| /api/instructions             |
| /api/events                  |
+------+----------------+------+
       |                |
       v                v
+--------------+  +----------------------+
| Linux procfs |  | Managed child + bounded demo workers |
| /proc/PID/   |  | subprocess.Popen     |
| status       |  | Python signal loop   |
+--------------+  +----------------------+
       ^                ^
       |                | os.kill(Popen.pid, allowlisted signal)
       +----------------+
```

## Request flow
1. Browser calls `/api/processes`; Flask enumerates numeric `/proc` entries and reads each available status file.
2. Browser calls `/api/health`; Flask reports Linux/procfs availability and the managed child status.
3. Start endpoint creates one child process and stores its `Popen` handle.
4. Signal endpoint accepts only an allowlisted signal name, obtains the PID from the stored handle, and calls `os.kill` on that PID.
5. Flask rereads procfs / waits for termination, then records the result in the event log.
6. Browser refreshes the process table, managed-process card, worker table, and event log.
7. The dashboard can create bounded batches of sleeping, memory-demo, or low-CPU workers. Every created PID is tracked using its `Popen` object. Worker signal endpoints refuse PIDs outside this in-memory registry.
8. The instruction endpoint parses a small allowlisted grammar and never passes user text to a shell or `eval`.

## Safety boundaries
- The API never accepts a target PID from the client.
- Signal names are checked against a fixed allowlist.
- Only the PID of the app-managed `Popen` child is targeted.
- The server binds to `127.0.0.1`, not all network interfaces.
- No shell is invoked and no browser-supplied string is executed as a command.
- The project is for local demonstration and is not designed for public exposure.

## Process state reference
Linux `/proc/PID/status` exposes a `State` line. Common codes include `R` running/runnable, `S` interruptible sleep, `D` uninterruptible sleep, `T` stopped, `Z` zombie, and `I` idle. A paused demo process should report `T` until continued.
