# Test Cases and Validation

## Automated tests

Run in Ubuntu terminal:

```bash
source .venv/bin/activate
python -m unittest discover -s tests -v
```

The suite uses Flask's test client and starts a real child process for signal lifecycle checks. It should be run on Linux/Ubuntu (including Ubuntu on WSL).

## Manual acceptance checklist

- [ ] `python app.py` starts and prints the local URL without traceback.
- [ ] `http://127.0.0.1:5000/` loads the dashboard.
- [ ] Backend status shows connected.
- [ ] Process table shows PIDs from `/proc`, states, and RSS.
- [ ] Visible process count changes or matches the current host snapshot.
- [ ] Start demo shows a managed PID and enables controls.
- [ ] Pause produces Linux state `T` / Stopped.
- [ ] Resume moves the process out of state `T`.
- [ ] Interrupt exits the child and records `SIGINT`.
- [ ] Start again, then terminate; child exits and `SIGTERM` is logged.
- [ ] Unsupported signal returns HTTP 400 and a meaningful error.
- [ ] Signaling with no active child returns HTTP 409.
- [ ] Create a batch of 5 or 10 sleeping demo workers from the dashboard.
- [ ] Confirm each worker row has a distinct real PID and a state/RSS value.
- [ ] Pause a managed worker and verify `T` / Stopped, then resume it.
- [ ] Terminate a managed worker and confirm it disappears from the active worker table.
- [ ] Try the instruction `create 5 sleepers` and confirm PIDs are returned.
- [ ] Try an unsupported instruction and confirm it is rejected without executing shell input.
- [ ] Verify a PID not created by the dashboard cannot be signaled through the worker API.
- [ ] Confirm bulk cleanup terminates only dashboard-created extra workers.
- [ ] No API accepts an arbitrary target PID for signal delivery.
- [ ] Stop the server with Ctrl+C; the managed child is cleaned up.

## Expected API behavior

| Scenario | Expected |
|---|---|
| GET `/api/health` | HTTP 200, `ok: true` |
| GET `/api/processes` | HTTP 200, array plus count |
| POST `/api/demo/start` first time | HTTP 201, managed PID |
| POST `/api/demo/start` while active | HTTP 409 |
| POST `/api/demo/signal` with unsupported value | HTTP 400 |
| POST `/api/demo/signal` without active child | HTTP 409 |
| SIGSTOP then SIGCONT | Process stops then resumes |
| SIGINT or SIGTERM | Managed child exits; event is logged |

## Troubleshooting failed tests
- If a test fails because process state updates slowly, rerun on a normal Ubuntu environment; state observation is kernel-scheduled and asynchronous.
- If a child remains after an interrupted test, stop the Flask server; cleanup is registered with `atexit`.
- Tests do not require root. Do not change them to signal arbitrary system PIDs.
