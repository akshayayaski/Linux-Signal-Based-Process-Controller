# 5–7 Minute Hackathon Presentation Outline

## 0:00–0:40 — Introduction
- Title: Linux Signal-Based Process Controller.
- Explain that signals are a standard way for processes to receive control requests.
- State the key distinction: the dashboard operates on a real Linux child process, not a frontend simulation.

## 0:40–1:25 — Problem and objectives
- Terminal commands are useful but can be intimidating for beginners.
- We want a visible, safe demonstration of process states and signal delivery.
- Objectives: live procfs monitoring, managed process controls, user-created demo worker batches, instruction field, REST API, event log.

## 1:25–2:15 — Architecture
- Browser UI calls Flask endpoints using JSON/HTTP.
- Flask reads `/proc/PID/status`.
- `subprocess.Popen` creates the demo process.
- `os.kill()` sends allowlisted signals only to the stored managed PID.

## 2:15–4:30 — Live demo
1. Show the process list and visible process count.
2. Click Start demo and identify the PID.
3. Click Pause; point out the `T` / Stopped state.
4. Click Resume; show that it returns to a runnable/sleeping state.
5. Send SIGINT and show the exit/event record.
6. Start a new child, send SIGTERM, and show termination.
7. Show event timestamps and operation results.
8. In the Demo Worker Lab, create 10 sleepers from the UI and show the distinct real PIDs. Pause/resume one worker, then clean up the batch.
9. Demonstrate the instruction field with `create 3 workers` to show that user instructions drive the UI actions through an allowlisted parser.

## 4:30–5:30 — Safety and testing
- No PID field is accepted from the browser.
- Signals are allowlisted.
- Service binds to localhost and does not need root.
- Explain API tests and manual acceptance checklist.

## 5:30–6:30 — Limitations and future work
- In-memory logs reset on restart.
- Local hackathon prototype, not production hardened.
- Future: SQLite, charts, authentication, process filters, deployment hardening.

## 6:30–7:00 — Conclusion
- Summarize the real OS integration.
- Invite questions about `/proc`, signal semantics, subprocess management, and Linux states.

## Likely viva questions

**Q: What is a signal in Linux?**  
A: An asynchronous notification delivered to a process to request an action or report an event.

**Q: What does SIGSTOP do?**  
A: It stops a process and cannot be caught or ignored.

**Q: What does SIGCONT do?**  
A: It resumes a stopped process.

**Q: Difference between SIGTERM and SIGKILL?**  
A: SIGTERM requests graceful termination and can be handled; SIGKILL forces termination and cannot be handled or ignored.

**Q: What is SIGINT?**  
A: An interrupt signal commonly associated with Ctrl+C. Here it is sent directly to the managed child and handled explicitly.

**Q: What is `/proc`?**  
A: A virtual filesystem exposing kernel and process information.

**Q: Why use `subprocess.Popen`?**  
A: It creates and tracks the exact child process the application is allowed to control.

**Q: Why not let the browser send a PID?**  
A: That could allow accidental or unauthorized signaling of unrelated processes.

**Q: Why does a stopped process show `T`?**  
A: Linux reports `T` for a job-control stop or signal stop.

**Q: Does this require root?**  
A: No. It signals only a child process owned by the same user.

**Q: Why Flask?**  
A: It provides a small Python HTTP API that is straightforward to connect to a browser UI.

**Q: What are the limitations?**  
A: Local-only educational prototype, volatile event history, permissions-dependent process visibility, and no production authentication.
