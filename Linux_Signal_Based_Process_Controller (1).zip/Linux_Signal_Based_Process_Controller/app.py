"""Linux Signal-Based Process Controller — safe local demo."""
from flask import Flask, jsonify, render_template, request
import os
import re
import signal
import subprocess
import sys
import threading
import time
from datetime import datetime, timezone

app = Flask(__name__)
app.config["JSON_SORT_KEYS"] = False

_lock = threading.RLock()
_managed = None
_workers = {}  # PID -> {process, kind, label, created_at}
_events = []
MAX_WORKERS = 50
MAX_BATCH = 30
MAX_MEMORY_MB = 32
MAX_EVENTS = 300
START_TOKEN = object()


def now():
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")


def log_event(action, pid=None, result="success", status="ok", detail=""):
    event = {"timestamp": now(), "signal": action, "pid": pid,
             "result": result, "status": status, "detail": detail}
    with _lock:
        _events.append(event)
        del _events[:-MAX_EVENTS]
    return event


def process_state(pid):
    """Read state/name/RSS from /proc/<pid>/status and stat."""
    try:
        with open(f"/proc/{pid}/status", "r", encoding="utf-8", errors="replace") as f:
            lines = f.readlines()
        fields = {}
        for line in lines:
            if ":" in line:
                key, value = line.split(":", 1)
                fields[key] = value.strip()
        state = fields.get("State", "unknown").split()[0]
        name = fields.get("Name", "unknown")
        vmrss = fields.get("VmRSS", "0 kB").split()
        memory_kb = int(vmrss[0]) if vmrss else 0
        return {"pid": pid, "name": name, "state": state,
                "state_label": {"R":"Running","S":"Sleeping","D":"Uninterruptible","T":"Stopped","t":"Tracing stop","Z":"Zombie","I":"Idle"}.get(state, state),
                "memory_kb": memory_kb}
    except (FileNotFoundError, ProcessLookupError, PermissionError, ValueError):
        return None


def process_list():
    rows = []
    try:
        entries = os.scandir("/proc")
    except OSError as exc:
        raise RuntimeError(f"Cannot read /proc: {exc}") from exc
    with entries:
        for entry in entries:
            if entry.name.isdigit():
                item = process_state(int(entry.name))
                if item:
                    rows.append(item)
    rows.sort(key=lambda x: x["pid"])
    return rows


def child_code():
    # A simple, isolated child that stays alive until it receives a signal.
    # Python's default SIGINT handler raises KeyboardInterrupt; SIGTERM exits.
    code = (
        "import signal,time,sys\n"
        "def stop(signum, frame):\n"
        " print('received', signal.Signals(signum).name, flush=True)\n"
        " if signum == signal.SIGINT: raise KeyboardInterrupt\n"
        " if signum == signal.SIGTERM: sys.exit(0)\n"
        "signal.signal(signal.SIGTERM, stop)\n"
        "signal.signal(signal.SIGINT, stop)\n"
        "print('managed-demo-ready', flush=True)\n"
        "while True: time.sleep(1)\n"
    )
    return [sys.executable, "-u", "-c", code]


def worker_code(kind, memory_mb=8):
    """Return a small, bounded child workload used only for dashboard demos."""
    if kind == "sleeper":
        code = "import time\ntime.sleep(600)\n"
    elif kind == "memory":
        # Cap memory per child and never exceed MAX_MEMORY_MB from user input.
        code = f"import time\ndata = bytearray({memory_mb} * 1024 * 1024)\ntime.sleep(600)\n"
    else:  # low-CPU heartbeat worker
        code = "import time\nwhile True: time.sleep(1)\n"
    return [sys.executable, "-u", "-c", code]


def workers_snapshot():
    """Return live dashboard-created worker metadata; reap exited children."""
    with _lock:
        result = []
        for pid, item in list(_workers.items()):
            proc = item["process"]
            if proc.poll() is not None:
                _workers.pop(pid, None)
                continue
            state = process_state(pid)
            result.append({"pid": pid, "kind": item["kind"], "label": item["label"],
                           "created_at": item["created_at"],
                           "state": state["state"] if state else "?",
                           "state_label": state["state_label"] if state else "Unknown",
                           "memory_kb": state["memory_kb"] if state else 0})
        return sorted(result, key=lambda item: item["pid"])


def create_workers(count, kind, memory_mb=8):
    if isinstance(count, bool) or not isinstance(count, int) or not 1 <= count <= MAX_BATCH:
        raise ValueError(f"Choose between 1 and {MAX_BATCH} processes per batch.")
    if kind not in ("sleeper", "memory", "worker"):
        raise ValueError("Choose sleeper, memory, or worker process type.")
    if isinstance(memory_mb, bool) or not isinstance(memory_mb, int) or not 1 <= memory_mb <= MAX_MEMORY_MB:
        raise ValueError(f"Memory size must be between 1 and {MAX_MEMORY_MB} MB per memory worker.")
    with _lock:
        # Reap stale entries before applying the cap.
        for pid, item in list(_workers.items()):
            if item["process"].poll() is not None:
                _workers.pop(pid, None)
        if len(_workers) + count > MAX_WORKERS:
            raise ValueError(f"The dashboard manages at most {MAX_WORKERS} extra demo workers at once. Stop some workers first.")
        created = []
        try:
            for index in range(count):
                proc = subprocess.Popen(worker_code(kind, memory_mb), stdin=subprocess.DEVNULL,
                                        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                        close_fds=True, start_new_session=True)
                label = f"{kind.title()} worker {index + 1}"
                _workers[proc.pid] = {"process": proc, "kind": kind, "label": label, "created_at": now()}
                created.append(proc.pid)
        except OSError:
            for pid in created:
                terminate_worker(pid, "SIGTERM", log=False)
            raise
        log_event("CREATE_BATCH", None, "success", "created",
                  f"Created {len(created)} {kind} demo process(es): {', '.join(map(str, created))}")
        return created


def terminate_worker(pid, signal_name, log=True):
    """Signal only a PID whose Popen object is in the dashboard-owned registry."""
    if signal_name not in ALLOWED_SIGNALS:
        raise ValueError("Unsupported signal.")
    with _lock:
        item = _workers.get(pid)
        if item is None:
            raise KeyError("That PID is not a live demo worker managed by this dashboard.")
        proc = item["process"]
        if proc.poll() is not None:
            _workers.pop(pid, None)
            raise KeyError("That demo worker has already exited.")
        try:
            os.kill(pid, ALLOWED_SIGNALS[signal_name])
            if signal_name in ("SIGTERM", "SIGINT"):
                try:
                    proc.wait(timeout=0.8)
                except subprocess.TimeoutExpired:
                    proc.kill()
                    proc.wait(timeout=0.8)
                _workers.pop(pid, None)
                state = "Exited"
            else:
                time.sleep(0.08)
                status = process_state(pid)
                state = status["state_label"] if status else "Unknown"
            if log:
                log_event(signal_name, pid, "success", state.lower(), f"{signal_name} sent to managed {item['kind']} worker.")
            return {"pid": pid, "signal": signal_name, "state": state}
        except ProcessLookupError:
            _workers.pop(pid, None)
            raise KeyError("That demo worker has already exited.")


def execute_instruction(text):
    """Small allowlisted command grammar; never runs user text as shell/code."""
    if not isinstance(text, str) or len(text) > 160:
        raise ValueError("Enter an instruction under 160 characters.")
    instruction = " ".join(text.strip().lower().split())
    match = re.fullmatch(r"(?:create|start) (\d{1,2}) (sleepers?|sleeping processes?)", instruction)
    if match:
        pids = create_workers(int(match.group(1)), "sleeper")
        return {"message": f"Created {len(pids)} sleeping demo process(es).", "pids": pids}
    match = re.fullmatch(r"(?:create|start) (\d{1,2}) (memory workers?|memory processes?)", instruction)
    if match:
        pids = create_workers(int(match.group(1)), "memory", 8)
        return {"message": f"Created {len(pids)} memory demo process(es) using up to 8 MB each.", "pids": pids}
    match = re.fullmatch(r"(?:create|start) (\d{1,2}) (workers?|background workers?)", instruction)
    if match:
        pids = create_workers(int(match.group(1)), "worker")
        return {"message": f"Created {len(pids)} low-CPU worker process(es).", "pids": pids}
    match = re.fullmatch(r"(pause|stop|resume|continue|interrupt|terminate) (?:pid )?(\d{1,10})", instruction)
    if match:
        verb, pid_text = match.groups()
        signal_name = {"pause":"SIGSTOP", "stop":"SIGSTOP", "resume":"SIGCONT", "continue":"SIGCONT", "interrupt":"SIGINT", "terminate":"SIGTERM"}[verb]
        result = terminate_worker(int(pid_text), signal_name)
        return {"message": f"{signal_name} sent to managed PID {result['pid']}; state: {result['state']}.", "pids": [result['pid']]}
    raise ValueError("Instruction not recognized. Try: 'create 10 sleepers', 'create 5 memory workers', 'create 3 workers', 'pause PID 1234', 'resume PID 1234', or 'terminate PID 1234'.")


def managed_info():
    global _managed
    with _lock:
        proc = _managed
        if proc is None:
            return {"running": False, "pid": None, "state": "Not started"}
        if proc.poll() is not None:
            pid = proc.pid
            _managed = None
            return {"running": False, "pid": pid, "state": "Exited"}
        state = process_state(proc.pid)
        return {"running": True, "pid": proc.pid,
                "state": state["state_label"] if state else "Unknown",
                "state_code": state["state"] if state else "?"}


@app.get("/")
def dashboard():
    return render_template("index.html")


@app.get("/api/health")
def health():
    return jsonify({"ok": True, "platform": sys.platform,
                    "proc_available": os.path.isdir("/proc"),
                    "managed": managed_info()})


@app.get("/api/processes")
def api_processes():
    try:
        rows = process_list()
        return jsonify({"processes": rows, "count": len(rows), "source": "/proc"})
    except RuntimeError as exc:
        return jsonify({"error": str(exc)}), 500


@app.post("/api/demo/start")
def start_demo():
    global _managed
    with _lock:
        if _managed is not None and _managed.poll() is None:
            return jsonify({"error": "The managed demo process is already running.",
                            "managed": managed_info()}), 409
        try:
            proc = subprocess.Popen(
                child_code(), stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                close_fds=True, start_new_session=True
            )
            _managed = proc
            log_event("START", proc.pid, "success", "started", "Managed demo process started.")
            return jsonify({"message": "Managed demo process started.", "managed": managed_info()}), 201
        except OSError as exc:
            log_event("START", None, "error", "failed", str(exc))
            return jsonify({"error": f"Could not start demo process: {exc}"}), 500


ALLOWED_SIGNALS = {"SIGSTOP": signal.SIGSTOP, "SIGCONT": signal.SIGCONT,
                   "SIGTERM": signal.SIGTERM, "SIGINT": signal.SIGINT}


@app.post("/api/demo/signal")
def signal_demo():
    global _managed
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        log_event("INVALID", None, "error", "rejected", "Expected a JSON object.")
        return jsonify({"error": "Request body must be a JSON object."}), 400
    name = data.get("signal")
    if not isinstance(name, str) or name not in ALLOWED_SIGNALS:
        log_event("INVALID", None, "error", "rejected", "Unsupported signal requested.")
        return jsonify({"error": "Signal must be one of SIGSTOP, SIGCONT, SIGTERM, SIGINT."}), 400
    with _lock:
        proc = _managed
        if proc is None or proc.poll() is not None:
            _managed = None
            log_event(name, None, "error", "rejected", "No active managed demo process.")
            return jsonify({"error": "No active managed demo process. Start it first."}), 409
        pid = proc.pid
        # Only signal the PID belonging to the Popen object created by this app.
        try:
            os.kill(pid, ALLOWED_SIGNALS[name])
            time.sleep(0.12)
            state = process_state(pid)
            if name in ("SIGTERM", "SIGINT"):
                # Give the child a brief chance to handle the signal.
                try:
                    proc.wait(timeout=0.8)
                except subprocess.TimeoutExpired:
                    # Escalation is limited to this exact managed child.
                    proc.kill()
                    proc.wait(timeout=0.8)
                _managed = None
                final_state = "Exited"
            else:
                final_state = state["state_label"] if state else "Unknown"
            log_event(name, pid, "success", final_state.lower(), f"{name} sent to managed process.")
            return jsonify({"message": f"{name} sent successfully.", "pid": pid,
                            "signal": name, "state": final_state, "managed": managed_info()}), 200
        except ProcessLookupError:
            _managed = None
            log_event(name, pid, "error", "not_found", "Managed process exited before signal delivery.")
            return jsonify({"error": "The managed process has already exited."}), 409
        except PermissionError:
            log_event(name, pid, "error", "permission_denied", "Permission denied.")
            return jsonify({"error": "Permission denied while signaling managed process."}), 403
        except OSError as exc:
            log_event(name, pid, "error", "failed", str(exc))
            return jsonify({"error": f"Signal operation failed: {exc}"}), 500


@app.get("/api/demo/workers")
def api_demo_workers():
    workers = workers_snapshot()
    return jsonify({"workers": workers, "count": len(workers), "max_workers": MAX_WORKERS})


@app.post("/api/demo/workers")
def api_create_workers():
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return jsonify({"error": "Request body must be a JSON object."}), 400
    try:
        pids = create_workers(data.get("count", 5), data.get("kind", "sleeper"), data.get("memory_mb", 8))
        return jsonify({"message": f"Created {len(pids)} demo process(es).", "pids": pids,
                        "workers": workers_snapshot()}), 201
    except ValueError as exc:
        log_event("CREATE_BATCH", None, "error", "rejected", str(exc))
        return jsonify({"error": str(exc)}), 400
    except OSError as exc:
        log_event("CREATE_BATCH", None, "error", "failed", str(exc))
        return jsonify({"error": f"Could not create demo processes: {exc}"}), 500


@app.post("/api/demo/workers/<int:pid>/signal")
def api_signal_worker(pid):
    data = request.get_json(silent=True)
    if not isinstance(data, dict) or not isinstance(data.get("signal"), str):
        return jsonify({"error": "Provide a supported signal."}), 400
    try:
        result = terminate_worker(pid, data["signal"])
        return jsonify({"message": f"{result['signal']} sent to PID {pid}.", **result}), 200
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400
    except KeyError as exc:
        log_event(data.get("signal", "INVALID"), pid, "error", "rejected", str(exc).strip("'"))
        return jsonify({"error": str(exc).strip("'")}), 404
    except PermissionError:
        return jsonify({"error": "Permission denied while signaling managed worker."}), 403
    except OSError as exc:
        return jsonify({"error": f"Signal operation failed: {exc}"}), 500


@app.post("/api/instructions")
def api_instruction():
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return jsonify({"error": "Request body must be a JSON object."}), 400
    try:
        result = execute_instruction(data.get("instruction", ""))
        log_event("USER_INSTRUCTION", None, "success", "completed", data.get("instruction", ""))
        return jsonify(result), 200
    except ValueError as exc:
        log_event("USER_INSTRUCTION", None, "error", "rejected", str(exc))
        return jsonify({"error": str(exc)}), 400
    except KeyError as exc:
        log_event("USER_INSTRUCTION", None, "error", "rejected", str(exc).strip("'"))
        return jsonify({"error": str(exc).strip("'")}), 404


@app.get("/api/events")
def events():
    with _lock:
        return jsonify({"events": list(reversed(_events))})


def cleanup():
    global _managed
    with _lock:
        proc = _managed
        _managed = None
        worker_pids = list(_workers)
    if proc is not None and proc.poll() is None:
        try:
            os.kill(proc.pid, signal.SIGTERM)
            proc.wait(timeout=1.0)
        except (ProcessLookupError, subprocess.TimeoutExpired, OSError):
            try:
                proc.kill()
                proc.wait(timeout=1.0)
            except (ProcessLookupError, subprocess.TimeoutExpired, OSError):
                pass
    for pid in worker_pids:
        try:
            terminate_worker(pid, "SIGTERM", log=False)
        except (KeyError, ValueError, OSError):
            pass


import atexit
atexit.register(cleanup)

if __name__ == "__main__":
    # Local demo only. Use a production WSGI server and authentication if exposed.
    app.run(host="127.0.0.1", port=5000, debug=False, threaded=True)
