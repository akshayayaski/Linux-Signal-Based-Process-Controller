# Linux Signal-Based Process Controller

A local Flask dashboard for demonstrating **real Linux process monitoring and POSIX signals**. This is a standalone project and does not depend on any other project.

## Features

- Live process list read from `/proc`, refreshed in the browser every 2 seconds.
- PID, process name, kernel process state, and resident memory (RSS).
- A dedicated Python child process started and tracked by this application.
- Real `SIGSTOP`, `SIGCONT`, `SIGINT`, and `SIGTERM` delivery using `os.kill()`.
- Timestamped event log and REST API errors.
- User-controlled creation of batches of real demo processes from the dashboard (sleeping, memory-demo, and low-CPU worker types).
- Per-worker Pause, Resume, and Terminate buttons, plus bulk cleanup of dashboard-created workers.
- An instruction box that accepts a limited, allowlisted set of plain-language commands, such as `create 10 sleepers` and `pause PID 12345`.
- Safety limits: up to 30 workers per batch, 50 extra managed workers at once, and up to 32 MB requested per memory worker.
- No arbitrary PID input for signal operations; signal actions only target processes registered as created by this app.
- Runs as an ordinary user on Ubuntu or Ubuntu on WSL; root is not required.

## Requirements

- Ubuntu 22.04/24.04 or a recent Ubuntu release (native Linux or Ubuntu on WSL).
- Python 3.10+ and `python3-venv`.
- A browser. VS Code is recommended but optional.

## Quick start (Ubuntu terminal)

From the extracted project directory:

```bash
sudo apt update
sudo apt install -y python3 python3-venv
chmod +x run.sh
./run.sh
```

The first run creates `.venv`, installs Flask, and starts the server. Keep this terminal open. The server listens on `http://127.0.0.1:5000` only.

Open your browser and visit **http://127.0.0.1:5000**. On WSL, localhost forwarding normally makes this address available in the Windows browser as well.

### Manual virtual environment setup

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python app.py
```

Stop the server with `Ctrl+C` in the Ubuntu terminal. On normal shutdown the app attempts to clean up its managed child process.

## Demo guide

1. Open the dashboard; confirm “Linux backend connected” and that processes populate from `/proc`.
2. Click **Start demo**. A managed PID appears.
3. Click **Pause (SIGSTOP)**. The process state should become **Stopped (T)**. Allow a refresh if necessary.
4. Click **Resume (SIGCONT)**. The process should leave the stopped state (usually sleeping, `S`, between loop iterations).
5. Click **Interrupt (SIGINT)**. The child handles SIGINT and exits; the dashboard returns to idle.
6. Start again and click **Terminate (SIGTERM)**. The child handles SIGTERM and exits.
7. Inspect the event log for timestamps, target PIDs, result, and operation status.
8. In **Process Lab**, choose a count (for example, 10) and a process type, then click **Create processes**. The table shows distinct real PIDs, state, and RSS. Pause/resume/terminate individual managed workers or use bulk cleanup.
9. Alternatively, use the instruction field with `create 10 sleepers`, `create 5 memory workers`, `create 3 workers`, `pause PID 12345`, `resume PID 12345`, or `terminate PID 12345`. For control instructions, replace `12345` with a PID from the **Managed demo workers** table. Only documented patterns are accepted; text is never executed as shell commands.

The `SIGINT` demonstration uses an explicit handler in the child, equivalent in effect to an interrupt request; sending SIGINT with `os.kill` does not simulate a keyboard press in the terminal.

## REST API

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/` | Dashboard HTML |
| GET | `/api/health` | Backend and managed-process status |
| GET | `/api/processes` | Actual process listing from `/proc` |
| POST | `/api/demo/start` | Start the app-managed child |
| POST | `/api/demo/signal` | Send one supported signal to that child |
| GET | `/api/events` | Recent in-memory event log |
| GET | `/api/demo/workers` | List extra demo workers created by the dashboard |
| POST | `/api/demo/workers` | Create a bounded batch of demo workers |
| POST | `/api/demo/workers/<pid>/signal` | Signal a dashboard-managed worker only |
| POST | `/api/instructions` | Run a supported allowlisted user instruction |

Signal request body example:

```json
{"signal":"SIGSTOP"}
```

Allowed signal values are exactly `SIGSTOP`, `SIGCONT`, `SIGTERM`, and `SIGINT`. The main demo endpoint obtains its PID from the stored child handle. The worker endpoint has a PID in its URL, but validates it against the dashboard-owned `Popen` registry before sending a signal; unrelated system PIDs are rejected.

## Tests

Run:

```bash
source .venv/bin/activate
python -m unittest discover -s tests -v
```

The tests use Flask's test client and a real managed child process. They do not signal arbitrary system processes. See `docs/test-cases.md`.

## Troubleshooting

- **`No module named venv` / ensurepip error:** install `python3-venv` with `sudo apt install python3-venv`.
- **Port 5000 already in use:** stop the other local service, or change `port=5000` near the bottom of `app.py` and use the same URL port.
- **Dashboard says backend disconnected:** keep `python app.py` running and reload `http://127.0.0.1:5000`.
- **Main signal buttons are disabled:** click Start demo first. These controls are deliberately disabled without a live managed process. Extra worker controls appear after creating workers in Process Lab.
- **State update seems delayed:** `/proc` and browser polling update every 2 seconds; allow a short moment after the signal.
- **WSL:** run the commands inside your Ubuntu distribution, not Windows PowerShell. Use the Ubuntu filesystem for the project when possible.

## Safety and scope

This is a hackathon/demo application, not a production process manager. It binds only to loopback, has no authentication or CSRF protection, and stores events in memory. Do not expose it to a network or use Flask's development server in production. Process enumeration is limited by the permissions of the user running the app. The all-process table is informational; signal controls apply only to the dedicated child or extra workers created and tracked by this dashboard. Extra worker registry and event history are in memory and reset when the server restarts. Do not use memory-demo workers on a low-memory machine or create the maximum number unless you need it for a demo.
